<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MissionReason extends Model
{
    //
}
