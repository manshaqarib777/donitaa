<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBranchsTableRollback extends Migration
{
    public function up()
    {
        Schema::dropIfExists('branchs');
    }

    public function down()
    {
        Schema::dropIfExists('branchs');
    }
}